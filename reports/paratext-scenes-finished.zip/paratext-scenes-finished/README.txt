A History of Framing — finished scene captures

Viewport: 1440 × 813 CSS pixels
Captured from each act’s authored settle point using the live Vite/browser runtime.
landing.png is the entry screen; 00–14 are the fifteen finished animation stations.

00-presentation.png  #bare
01-page.png  #page
02-outside-voice.png  #glosses
03-apparatus-print.png  #print
04-editorial-composition.png  #editorial
05-editorial-spread.png  #magazine
06-hypertext.png  #hypertext
07-application.png  #application
08-fragmented-frames.png  #fragments
09-ai-enters.png  #conversation
10-the-tube.png  #tube
11-delta-type-anywhere.png  #recovery
12-delta-virtualized-state.png  #projections
13-proposed-extension.png  #cost
14-interface-grows.png  #open
